import logging

def lambda_handler(event, context):
  logger = logging.getLogger()
  logger.setLevel(logging.INFO)
  
  bucket_name = event['Records'][0]['s3']['bucket']['name']
  object_key = event['Records'][0]['s3']['object']['key']
  
  logger.info(f'Operation requested to S3 object {object_key} of bucket {bucket_name}')
  
  return {
      'statusCode': 200,
      'body': 'S3 operation completed successfully'
  }
